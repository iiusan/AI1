﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            fP_data.AutoScroll = true;
        }

        private void nUD_nr_ValueChanged(object sender, EventArgs e)
        {
            fP_data.Controls.Clear();
            for (int i = 0; i < nUD_nr.Value; ++i)
                AddControl(fP_data);
        }


        private void AddControl(Control to)
        {
            var panel = new Panel();
            panel.Width = p_T.Width;
            panel.Height = p_T.Height;
            panel.BackColor = Color.Aqua;

            Label x = new Label();
            x.Location = label2.Location;
            x.Text = label2.Text;
            x.Width = label2.Width;
            panel.Controls.Add(x);
            x = new Label();
            x.Location = label3.Location;
            x.Text = label3.Text;
            x.Width = label3.Width;
            panel.Controls.Add(x);

            NumericUpDown n = new NumericUpDown();
            n.Location = numericUpDown2.Location;
            n.Value = numericUpDown2.Value;
            n.Width = numericUpDown2.Width;
            panel.Controls.Add(n);
            n = new NumericUpDown();
            n.Location = numericUpDown3.Location;
            n.Value = numericUpDown3.Value;
            n.Width = numericUpDown3.Width;
            panel.Controls.Add(n);

            to.Controls.Add(panel);
        }
    }
}
