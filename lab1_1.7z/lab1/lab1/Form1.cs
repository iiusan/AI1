﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            fP_data.AutoScroll = true;
            p_T.Hide();
            cB_func.SelectedValueChanged += CalcFunc;
            cB_func.SelectedIndex = 0;

            fP_data.Controls.Clear();
            for (int i = 0; i < nUD_nr.Value; ++i)
                AddControl(fP_data);
        }

        private void nUD_nr_ValueChanged(object sender, EventArgs e)
        {
            fP_data.Controls.Clear();
            for (int i = 0; i < nUD_nr.Value; ++i)
                AddControl(fP_data);
        }


        private void AddControl(Control to)
        {
            int i = 0;
            var panel = new Panel();
            panel.Width = p_T.Width;
            panel.Height = p_T.Height;
            panel.BackColor = Color.Aqua;

            Label x = new Label();
            x.Location = label2.Location;
            x.Text = label2.Text;
            x.Width = label2.Width;
            panel.Controls.Add(x);
            x = new Label();
            x.Location = label3.Location;
            x.Text = label3.Text;
            x.Width = label3.Width;
            panel.Controls.Add(x);

            NumericUpDown n = new NumericUpDown();
            n.ValueChanged += CalcFunc;
            n.DecimalPlaces = 2;
            n.Name = "x" +i;
            n.Location = numericUpDown2.Location;
            n.Value = numericUpDown2.Value;
            n.Increment = Convert.ToDecimal(0.01);
            n.Width = numericUpDown2.Width;
            panel.Controls.Add(n);
            n = new NumericUpDown();
            n.Name = "w" + i;
            n.DecimalPlaces = 2;
            n.ValueChanged += CalcFunc;
            n.Location = numericUpDown3.Location;
            n.Value = numericUpDown3.Value;
            n.Width = numericUpDown3.Width;
            n.Increment = Convert.ToDecimal(0.01);
            panel.Controls.Add(n);

            to.Controls.Add(panel);
        }



        private void CalcFunc(object sender, EventArgs e)
        {
            string val = cB_func.Text;
            tB_intVal.Text = GetValuesFor(val).ToString();
        }



        private double GetValuesFor(string fType)
        {
            int count = fP_data.Controls.Count;
            
            double results = 0;
            if (fType == "produs")
                results = 1;
            if (fType == "min")
                results = 999999999999;
            if (fType == "max")
                results = -999999999999;
            for (int i = 0; i < count; ++i)
            {
                double p = Convert.ToDouble(fP_data.Controls[i].Controls[3].Text) * Convert.ToDouble(fP_data.Controls[i].Controls[2].Text);
                if (fType == "suma")
                    results += p;
                if (fType == "produs")
                    results *= p;
                if (fType == "min")
                    results = Math.Min(p, results);
                if (fType == "max")
                    results = Math.Max(p, results);
            }

            return results;
        }
    }
}
