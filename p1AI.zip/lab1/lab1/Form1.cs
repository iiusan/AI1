﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            fP_data.AutoScroll = true;
            p_T.Hide();
            cB_func.SelectedValueChanged += CalcFunc;
            cB_func.SelectedIndex = 0;
            cB_actFunc.SelectedIndex = 0;

            fP_data.Controls.Clear();
            for (int i = 0; i < nUD_nr.Value; ++i)
                AddControl(fP_data, i);


            cB_actFunc.SelectedValueChanged += CalcActFunc;
            nUP_t.ValueChanged += CalcActFunc;
            nUP_ga.ValueChanged += CalcActFunc;
            tB_binary.CheckedChanged += CalcActBinaryFunc;
            ShowControlsFor(cB_actFunc.Text);
        }

        private void nUD_nr_ValueChanged(object sender, EventArgs e)
        {
            fP_data.Controls.Clear();
            for (int i = 0; i < nUD_nr.Value; ++i)
                AddControl(fP_data, i);
        }


        private void AddControl(Control to, int i)
        {
            var panel = new Panel();
            panel.Width = p_T.Width;
            panel.Height = p_T.Height;
            panel.BackColor = Color.Aqua;

            Label x = new Label();
            x.Location = label2.Location;
            x.Text = label2.Text+i;
            x.Width = 30; 
            panel.Controls.Add(x);
            x = new Label();
            x.Location = label3.Location;
            x.Text = label3.Text+i;
            x.Width  = 30;
            panel.Controls.Add(x);


            NumericUpDown n = new NumericUpDown();
            n.Minimum = -999999;//
            n.ValueChanged += CalcFunc;
            n.DecimalPlaces = 2;
            n.Location = numericUpDown2.Location;
            n.Value = numericUpDown2.Value;
            n.Increment = Convert.ToDecimal(0.01);
            n.Width = numericUpDown2.Width;
            panel.Controls.Add(n);
            n = new NumericUpDown();
            n.DecimalPlaces = 2;
            n.ValueChanged += CalcFunc;
            n.Location = numericUpDown3.Location;
            n.Value = numericUpDown3.Value;
            n.Width = numericUpDown3.Width;
            n.Minimum = -999999;///
            n.Increment = Convert.ToDecimal(0.01);
            panel.Controls.Add(n);
            x = new Label();
            x.Location = arrow.Location;
            x.Text = arrow.Text;
            x.Width = arrow.Width;
            panel.Controls.Add(x);
            to.Controls.Add(panel);
        }



        private void CalcFunc(object sender, EventArgs e)
        {
            string val = cB_func.Text;
            tB_intVal.Text = GetValuesFor(val).ToString();
            CalcActFunc(sender, e);
        }

        private void CalcActFunc(object sender, EventArgs e)
        {
            string val = cB_actFunc.Text;
            ShowControlsFor(val);
            double act = GetActFor(val);
            tB_act.Text =act.ToString();
            tB_out.Text = act.ToString();
            if (tB_binary.Checked)
                tB_fOut.Text = GetActBinaryForRes(val).ToString();
            else
                tB_fOut.Text = act.ToString();
        }

        private void CalcActBinaryFunc(object sender, EventArgs e)
        {
            string val = cB_actFunc.Text;
            ShowControlsFor(val);
            double act = GetActFor(val);
            if (tB_binary.Checked)
                tB_fOut.Text = GetActBinaryForRes(val).ToString();
            else
                tB_fOut.Text = tB_out.Text;
        }
        private double GetValuesFor(string fType)
        {
            int count = fP_data.Controls.Count;
            
            double results = 0;
            if (fType == "produs")
                results = 1;
            if (fType == "min")
                results = 999999999999;
            if (fType == "max")
                results = -999999999999;
            for (int i = 0; i < count; ++i)
            {
                double p = Convert.ToDouble(fP_data.Controls[i].Controls[3].Text) * Convert.ToDouble(fP_data.Controls[i].Controls[2].Text);
                if (fType == "suma")
                    results += p;
                if (fType == "produs")
                    results *= p;
                if (fType == "min")
                    results = Math.Min(p, results);
                if (fType == "max")
                    results = Math.Max(p, results);
            }

            return results;
        }



        private double GetActFor(string actType)
        {
            double x = Convert.ToDouble(tB_intVal.Text), t = Convert.ToDouble(nUP_t.Text), g = Convert.ToDouble(nUP_ga.Text);
            if (actType == "sin")
                return Sigmoid(x, g, t);
            if (actType == "treapta")
                return Treapta(x, t);
            if (actType == "semn")
                return Semn(x);
            if (actType == "tanh")
                return TanH(x, g, t);
            if (actType == "rampa")
                return Rampa(x, g);
            return 0;
        }

        private void ShowControlsFor(string actType)
        {
            p_gVal.Hide();
            p_tVal.Hide();

            if (actType == "sin")
            {
                p_tVal.Show();
                p_gVal.Show();
            }
            if (actType == "treapta")
                {
                    p_tVal.Show();
                }
            if (actType == "tanh")
            {
                p_tVal.Show();
                p_gVal.Show();
            }
            if (actType == "rampa")
                p_gVal.Show();
        }


        private double GetActBinaryForRes(string actType)
        {
            double x = Convert.ToDouble(tB_intVal.Text), t = Convert.ToDouble(nUP_t.Text), g = Convert.ToDouble(nUP_ga.Text);
            if (actType == "sin")
                return SigmoidBinary(x, g, t);
            if (actType == "treapta")
                return Treapta(x, t);
            if (actType == "semn")
                return Semn(x);
            if (actType == "tanh")
                return TanHBinary(x, g, t);
            if (actType == "rampa")
                return RampaBinary(x, g);
            return 0;
        }



        #region Rampa
        private double Rampa(double x, double g)
        {
            if (x >= g) return 1;
            if (x < g * -1) return -1;
            return x / g;
        }
        private double RampaBinary(double x, double g)
        {
            return ToBinary(Rampa(x, g), -1, 1);
        }
        #endregion

        #region Tanh
        private double TanH(double x, double g, double t)
        {
            double up = Math.Pow(Math.E, g * (x - t)) - Math.Pow(Math.E, -1 * g * (x - t));
            double down =Math.Pow(Math.E, g*(x-t)) + Math.Pow(Math.E, -1 * g * (x - t));
            return up / down;
        }
        private double TanHBinary(double x, double g, double t)
        {
            return ToBinary(TanH(x, g, t), -1, 1);
        }
        #endregion

        #region Semn
        private double Semn(double x)
        {
            return x >= 0 ? 1 : -1;
        }
        #endregion

        #region Treapta
        private double Treapta(double x, double t)
        {
            return x >= t ? 1 : 0;
        }
        #endregion

        #region Sigmoid
        private double Sigmoid(double x, double g, double t)
        {
            g = g * -1;
           return 1 / (1 + Math.Pow(Math.E, g*(x-t)));
        }

        private double SigmoidBinary(double x, double g, double t)
        {
            return ToBinary(Sigmoid(x, g, t), 0, 1);
        }

        private double ToBinary(double x, double limLeft, double limRight)
        {
            double mid = (limLeft + limRight) / 2;
            if (x < mid)
                return limLeft;
            else
                return limRight;
        }
        #endregion
    }
}
